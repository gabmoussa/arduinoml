#ifndef STATE_H
#define STATE_H

#include <string>
#include <iterator>
#include <list>

#include "Action.h"
#include "ActuatorState.h"

namespace arduino_ml 
{
	class Transition; /**< Forward declaration of Transition to avoid a include cycle */

	/**
	 * A state memorize a set of actions & possibles transitions.
	 * These actions are executed when the state is activated 
	 */
	class State
	{
	public:
		State(const std::string& name) : name_(name) { }
		inline const std::string& name() const { return name_; }
		inline void add_action(Actuator* actuator, ActuatorState nextState) { actions_.push_back(new Action(actuator, nextState)); }
		inline void add_transition(Transition* transition) { transitions_.push_back(transition); }
		inline std::list<Action*>& actions() { return actions_; }
		inline std::list<Transition*>& transitions() { return transitions_; }
		
		void exec_actions() { }

	private:
		std::string name_;  /**< The state's name */
		std::list<Action*> actions_;	/**< The actions to execute when in that state */
		std::list<Transition*> transitions_;	/**< The possibles transitions */
	};
}

#endif