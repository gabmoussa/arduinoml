#ifndef ACTUATOR_H
#define ACTUATOR_H
 
#include <string>
#include "Arduino.h"
#include "ActuatorState.h"
#include "IO_TYPE.h"
 
 
 namespace arduino_ml 
 {	
	/**
	 * An actuator is a device that can be connected to an arduino's pin.
	 */
	class Actuator
	{
	  public:
	  
		Actuator(const std::string& name, int pin_number, 
				 IO_TYPE io_type = INPUT_DEVICE,
				 ActuatorState current_state = LOW_STATE
				 )
			: name_(name), pin_number_(pin_number), io_type_(io_type), current_state_(current_state) { }
		virtual ~Actuator() { };

		inline const std::string&  name() const { return name_;  }
		inline int pin_number() const { return pin_number_;  }
		inline void set_pin_number(int pin_number) { pin_number_ = pin_number; }
		inline IO_TYPE io_type() const { return io_type_;  }
		inline void set_io_type(IO_TYPE io_type) { io_type_ = io_type; }
		inline ActuatorState  current_state() const { return current_state_;  }
		inline void set_current_state(ActuatorState state) 
		{	
			current_state_ = state; 
			digitalWrite(pin_number_,static_cast<int>(current_state_)); 
		}
	  
	private:
		  std::string name_;
		  int pin_number_;
		  IO_TYPE io_type_;
		  ActuatorState current_state_;
	};
}

#endif 