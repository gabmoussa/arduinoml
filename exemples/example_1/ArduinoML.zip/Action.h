
#ifndef ACTION_H
#define ACTION_H	

#include "ActuatorState.h"
#include "Actuator.h"


namespace arduino_ml
{
	/**
	 * An action refer to an actuator's state change. 
	 */
	class Action
	{
	public:
		Action(Actuator* actuator,ActuatorState actuator_state) 
			: actuator_(actuator), actuator_state_(actuator_state) { }
		
		ActuatorState actuator_state() { return actuator_state_; }
		Actuator* actuator() { return actuator_; }
		
	private:
		Actuator* actuator_;
		ActuatorState actuator_state_;
	};
	
}

#endif 