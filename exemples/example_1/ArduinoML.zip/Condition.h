#ifndef CONDITION_H
#define CONDITION_H	

#include "ActuatorState.h"

class Actuator;

namespace arduino_ml
{
	/**
	 * A condition is compose by an actuator & an actuator state.
	 * The condition is verified if the actuator is in the indicated state.
	 */
	class Condition
	{
	public:
		Condition(Actuator* actuator,ActuatorState actuator_state) 
			: actuator_(actuator), actuator_state_(actuator_state) { }
		bool isValid() { return actuator_->current_state() == actuator_state_; }
		
	private:
		Actuator* actuator_;	/**< The actuator */
		ActuatorState actuator_state_;  /**< State of the actuator to match */
	};
}

#endif 